var typed=new Typed(".text",{
    strings:["Frontend Developer","Devops Engineer" ],
    typespeed:100,
    backSpeed:100,
    backDelay:1000,
    loop:true,
});

const refreshInterval = 7000; // 5000 milliseconds = 5 seconds
// Function to reload the page
function reloadPage() {
 location.reload(true); 
}
setTimeout(reloadPage, refreshInterval);